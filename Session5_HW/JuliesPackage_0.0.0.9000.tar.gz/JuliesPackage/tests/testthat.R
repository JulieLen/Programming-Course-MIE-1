library(testthat)
library(JuliesPackage)

test_check("JuliesPackage")
